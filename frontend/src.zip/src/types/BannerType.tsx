export type BannerType = {
  id: number;
  banner: string;
};
