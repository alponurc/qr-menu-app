export type NotificationType = {
  id?: number;
  date?: string;
  title?: string;
  description?: string;
};
