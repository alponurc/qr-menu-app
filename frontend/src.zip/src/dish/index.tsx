import {DishName} from './DishName';
import {DishPrice} from './DishPrice';

export const dish = {
  DishName,
  DishPrice,
};
