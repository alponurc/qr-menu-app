import {getDishes} from './getDishes';

export const data = {
  getDishes,
};
