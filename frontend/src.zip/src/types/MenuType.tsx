export type MenuType = {
  id: number;
  name: string;
  image: string;
};
