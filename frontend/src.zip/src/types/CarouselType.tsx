export type CarouselType = {
  id: number;
  banner: string;
};
