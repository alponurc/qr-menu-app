export type ColorType = {
  id: number;
  name: string;
  code: string;
};
