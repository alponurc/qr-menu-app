export type StatisticType = {
  id: number;
  name: string;
  transactionsQty: number;
  amount: number;
  inPercent: number;
  icon: string;
};
