export type PromocodeType = {
  id: number;
  name: string;
  code: string;
  image: string;
  expiry: string;
  discount: number;
};
